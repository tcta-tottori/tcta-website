/*!
 * 鳥取市テニス協会 公式サイト — 共通スクリプト
 * すべての機能は「その要素がページにあるときだけ」動きます。
 */
(function () {
  'use strict';

  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- スクロール連動フェード（.rv） ---------- */
  function initReveal() {
    var targets = document.querySelectorAll('.rv');
    if (!targets.length) return;

    if (!('IntersectionObserver' in window) || reduceMotion) return; // そのまま表示

    document.body.classList.add('jsrv');
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          e.target.classList.add('on');
          io.unobserve(e.target);
        }
      });
      // 閾値は 0（＋下端マージン）にしておく。割合で判定すると、
      // 一覧表のように画面より背の高い要素が永久に表示されないことがある。
    }, { threshold: 0, rootMargin: '0px 0px -60px 0px' });

    requestAnimationFrame(function () {
      targets.forEach(function (el) { io.observe(el); });
    });
  }

  /* ---------- ヘッダー（スクロールで影・モバイルメニュー） ---------- */
  function initHeader() {
    var header = document.querySelector('.site-header');
    if (!header) return;

    if (!header.classList.contains('site-header--overlay')) {
      var onScroll = function () {
        header.classList.toggle('hsh', window.scrollY > 100);
      };
      window.addEventListener('scroll', onScroll, { passive: true });
      onScroll();
    }

    var toggle = document.querySelector('.hamburger');
    var menu = document.getElementById('mobile-nav');
    if (!toggle || !menu) return;

    var setOpen = function (open) {
      if (open) {
        // ヘッダー（通知バーの有無で高さが変わる）の真下から始める
        menu.style.paddingTop = (header.getBoundingClientRect().bottom + 24) + 'px';
      }
      toggle.setAttribute('aria-expanded', String(open));
      menu.classList.toggle('is-open', open);
      document.body.classList.toggle('is-locked', open);
      menu.setAttribute('aria-hidden', String(!open));
    };

    toggle.addEventListener('click', function () {
      setOpen(toggle.getAttribute('aria-expanded') !== 'true');
    });
    menu.addEventListener('click', function (e) {
      if (e.target.closest('a')) setOpen(false);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && toggle.getAttribute('aria-expanded') === 'true') {
        setOpen(false);
        toggle.focus();
      }
    });
    window.addEventListener('resize', function () {
      if (window.innerWidth >= 1024 && toggle.getAttribute('aria-expanded') === 'true') setOpen(false);
    });

    setOpen(false);
  }

  /* ---------- 大会カルーセル ---------- */
  function initCarousel() {
    var track = document.querySelector('[data-carousel]');
    if (!track) return;

    var step = function () {
      var card = track.querySelector('.tcard');
      if (!card) return 320;
      var gap = parseFloat(getComputedStyle(track).columnGap || '24') || 24;
      return card.getBoundingClientRect().width + gap;
    };

    document.querySelectorAll('[data-carousel-prev]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        track.scrollBy({ left: -step(), behavior: reduceMotion ? 'auto' : 'smooth' });
      });
    });
    document.querySelectorAll('[data-carousel-next]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        track.scrollBy({ left: step(), behavior: reduceMotion ? 'auto' : 'smooth' });
      });
    });

    // 初期表示：TODAY マーカーの手前に「終了した大会」1枚が見える位置へ
    var marker = track.querySelector('[data-carousel-today]');
    if (marker) {
      var place = function () {
        track.scrollLeft = Math.max(0, marker.offsetLeft - step());
      };
      place();
      window.addEventListener('load', place);
      window.addEventListener('resize', place);
    }
  }

  /* ---------- 一覧のフィルタチップ（大会情報ページ） ---------- */
  function initFilters() {
    var groups = document.querySelectorAll('[data-filter-group]');
    if (!groups.length) return;

    groups.forEach(function (group) {
      var targetSel = group.getAttribute('data-filter-target');
      var rows = document.querySelectorAll(targetSel + ' [data-tags]');
      var empty = document.querySelector(targetSel + '-empty');

      group.addEventListener('click', function (e) {
        var chip = e.target.closest('.chip');
        if (!chip) return;

        group.querySelectorAll('.chip').forEach(function (c) {
          var active = c === chip;
          c.classList.toggle('is-active', active);
          c.setAttribute('aria-pressed', String(active));
        });

        var key = chip.getAttribute('data-filter');
        var shown = 0;
        rows.forEach(function (row) {
          var match = key === 'all' || (' ' + row.getAttribute('data-tags') + ' ').indexOf(' ' + key + ' ') > -1;
          row.hidden = !match;
          if (match) shown++;
        });
        if (empty) empty.hidden = shown !== 0;
      });
    });
  }

  /* ---------- 年度タブ（大会結果ページ など） ---------- */
  function initTabs() {
    var lists = document.querySelectorAll('[role="tablist"]');
    if (!lists.length) return;

    lists.forEach(function (list) {
      var tabs = Array.prototype.slice.call(list.querySelectorAll('[role="tab"]'));

      var select = function (tab) {
        tabs.forEach(function (t) {
          var on = t === tab;
          t.classList.toggle('is-active', on);
          t.setAttribute('aria-selected', String(on));
          t.tabIndex = on ? 0 : -1;
          var panel = document.getElementById(t.getAttribute('aria-controls'));
          if (panel) panel.hidden = !on;
        });
      };

      list.addEventListener('click', function (e) {
        var tab = e.target.closest('[role="tab"]');
        if (tab) select(tab);
      });

      list.addEventListener('keydown', function (e) {
        var i = tabs.indexOf(document.activeElement);
        if (i < 0) return;
        var next = e.key === 'ArrowRight' ? i + 1 : e.key === 'ArrowLeft' ? i - 1 : -1;
        if (next < 0) return;
        e.preventDefault();
        var target = tabs[(next + tabs.length) % tabs.length];
        target.focus();
        select(target);
      });
    });
  }

  /* ---------- お問い合わせフォーム ---------- */
  function initForm() {
    var form = document.querySelector('[data-validate]');
    if (!form) return;

    var done = document.querySelector('[data-form-done]');

    var showError = function (field, message) {
      var box = form.querySelector('[data-error-for="' + field.name + '"]');
      field.setAttribute('aria-invalid', 'true');
      if (box) {
        box.textContent = '⚠ ' + message;
        box.classList.add('is-shown');
      }
    };

    var clearError = function (field) {
      var box = form.querySelector('[data-error-for="' + field.name + '"]');
      field.removeAttribute('aria-invalid');
      if (box) box.classList.remove('is-shown');
    };

    var validate = function (field) {
      var value = (field.value || '').trim();

      if (field.type === 'checkbox') {
        if (field.required && !field.checked) {
          showError(field, '同意が必要です。');
          return false;
        }
      } else if (field.required && !value) {
        showError(field, field.getAttribute('data-label') + 'を入力してください。');
        return false;
      } else if (field.type === 'email' && value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        showError(field, 'メールアドレスの形式が正しくありません（@を含む形式で入力してください）。');
        return false;
      }
      clearError(field);
      return true;
    };

    var fields = Array.prototype.slice.call(form.querySelectorAll('input, textarea, select'));
    fields.forEach(function (field) {
      field.addEventListener('blur', function () { validate(field); });
      field.addEventListener('input', function () {
        if (field.getAttribute('aria-invalid') === 'true') validate(field);
      });
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var firstBad = null;
      fields.forEach(function (field) {
        if (!validate(field) && !firstBad) firstBad = field;
      });

      if (firstBad) {
        firstBad.focus();
        firstBad.scrollIntoView({ block: 'center', behavior: reduceMotion ? 'auto' : 'smooth' });
        return;
      }

      // 実サーバー接続前のプロトタイプ動作：送信完了画面を表示
      form.hidden = true;
      if (done) {
        done.classList.add('is-shown');
        done.setAttribute('tabindex', '-1');
        done.focus();
        done.scrollIntoView({ block: 'center', behavior: reduceMotion ? 'auto' : 'smooth' });
      }
    });
  }

  function init() {
    initReveal();
    initHeader();
    initCarousel();
    initFilters();
    initTabs();
    initForm();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
